// backend/routes/accountManagement.js

const express = require('express');
const authenticateToken = require('../middleware/authenticateToken');
const User = require('../models/User');
const WeeklyLateTracking = require('../models/WeeklyLateTracking');
const { unlockUserAccount, getWeeklyLateStats } = require('../services/weeklyLateTrackingService');

const router = express.Router();

// Middleware to check if user is Admin or HR
const isAdminOrHr = (req, res, next) => {
    if (req.user.role !== 'Admin' && req.user.role !== 'HR') {
        return res.status(403).json({ error: 'Access denied. Admin or HR role required.' });
    }
    next();
};

// GET /api/admin/locked-accounts - Get all locked accounts
router.get('/locked-accounts', [authenticateToken, isAdminOrHr], async (req, res) => {
    try {
        const lockedUsers = await User.find({
            accountLocked: true
        })
        .select('fullName email employeeCode department lockedAt lockedReason')
        .sort({ lockedAt: -1 })
        .lean();

        // Get weekly stats for each locked user
        const usersWithStats = await Promise.all(
            lockedUsers.map(async (user) => {
                const stats = await getWeeklyLateStats(user._id);
                return {
                    ...user,
                    weeklyStats: stats
                };
            })
        );

        res.json(usersWithStats);
    } catch (error) {
        console.error('Error fetching locked accounts:', error);
        res.status(500).json({ error: 'Failed to fetch locked accounts' });
    }
});

// POST /api/admin/unlock-account - Unlock a user account
router.post('/unlock-account', [authenticateToken, isAdminOrHr], async (req, res) => {
    try {
        const { userId, reason } = req.body;

        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }

        if (!reason || reason.trim().length === 0) {
            return res.status(400).json({ error: 'Unlock reason is required' });
        }

        // Check if user exists and is locked
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        if (!user.accountLocked) {
            return res.status(400).json({ error: 'User account is not locked' });
        }

        // Unlock the account
        await unlockUserAccount(userId, req.user.userId, reason);

        res.json({ 
            message: 'Account unlocked successfully',
            user: {
                fullName: user.fullName,
                email: user.email,
                unlockedBy: req.user.userId,
                unlockedAt: new Date()
            }
        });
    } catch (error) {
        console.error('Error unlocking account:', error);
        res.status(500).json({ error: 'Failed to unlock account' });
    }
});

// POST /api/admin/lock-account - Manually lock a user account (Admin/HR action)
router.post('/lock-account', [authenticateToken, isAdminOrHr], async (req, res) => {
    try {
        const { userId, reason } = req.body;

        if (!userId) {
            return res.status(400).json({ error: 'User ID is required' });
        }

        if (!reason || reason.trim().length === 0) {
            return res.status(400).json({ error: 'Lock reason is required' });
        }

        // Check if user exists
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        if (user.accountLocked) {
            return res.status(400).json({ error: 'User account is already locked' });
        }

        // Lock the account - keep isActive true but set accountLocked true
        // This allows the account to be found by login system but blocked by lock check
        await User.findByIdAndUpdate(userId, {
            accountLocked: true,
            lockedReason: reason,
            lockedAt: new Date(),
            unlockedAt: null,
            unlockedBy: null
            // Note: We don't set isActive: false to ensure the user can be found for lock checking
        });

        res.json({ 
            message: 'Account locked successfully',
            user: {
                fullName: user.fullName,
                email: user.email,
                lockedAt: new Date(),
                lockedBy: req.user.userId
            }
        });
    } catch (error) {
        console.error('Error locking account:', error);
        res.status(500).json({ error: 'Failed to lock account' });
    }
});

// GET /api/admin/user-late-stats/:userId - Get late statistics for a specific user
router.get('/user-late-stats/:userId', [authenticateToken, isAdminOrHr], async (req, res) => {
    try {
        const { userId } = req.params;
        
        const user = await User.findById(userId).select('fullName email employeeCode');
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        const stats = await getWeeklyLateStats(userId);
        
        res.json({
            user: {
                fullName: user.fullName,
                email: user.email,
                employeeCode: user.employeeCode
            },
            weeklyStats: stats
        });
    } catch (error) {
        console.error('Error fetching user late stats:', error);
        res.status(500).json({ error: 'Failed to fetch user statistics' });
    }
});

// GET /api/admin/debug-account-state/:email - Debug endpoint to check account state
router.get('/debug-account-state/:email', [authenticateToken, isAdminOrHr], async (req, res) => {
    try {
        const { email } = req.params;
        
        // Find user by email or employee code with shift information
        const user = await User.findOne({
            $or: [
                { email: email }, 
                { employeeCode: email }
            ]
        }).populate('shiftGroup').select('fullName email employeeCode isActive accountLocked lockedReason lockedAt unlockedAt unlockedBy shiftGroup');
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        res.json({
            user: {
                _id: user._id,
                fullName: user.fullName,
                email: user.email,
                employeeCode: user.employeeCode,
                isActive: user.isActive,
                accountLocked: user.accountLocked,
                lockedReason: user.lockedReason,
                lockedAt: user.lockedAt,
                unlockedAt: user.unlockedAt,
                unlockedBy: user.unlockedBy,
                shiftGroup: user.shiftGroup
            }
        });
    } catch (error) {
        console.error('Error fetching user debug info:', error);
        res.status(500).json({ error: 'Failed to fetch user debug information' });
    }
});

// GET /api/admin/debug-attendance-status/:email - Debug attendance status for user
router.get('/debug-attendance-status/:email', [authenticateToken, isAdminOrHr], async (req, res) => {
    try {
        const { email } = req.params;
        const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
        
        // Find user by email or employee code
        const user = await User.findOne({
            $or: [
                { email: email }, 
                { employeeCode: email }
            ]
        }).populate('shiftGroup');
        
        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Simulate the attendance status endpoint logic
        const attendanceLog = await require('../models/AttendanceLog').findOne({ 
            user: user._id, 
            attendanceDate: today 
        });

        const response = {
            user: {
                _id: user._id,
                fullName: user.fullName,
                email: user.email,
                employeeCode: user.employeeCode,
                isActive: user.isActive,
                accountLocked: user.accountLocked
            },
            attendanceData: {
                date: today,
                hasAttendanceLog: !!attendanceLog,
                attendanceLogId: attendanceLog?._id,
                userShift: user.shiftGroup,
                shiftName: user.shiftGroup?.shiftName || 'No shift assigned',
                shiftType: user.shiftGroup?.shiftType || 'N/A',
                shiftStartTime: user.shiftGroup?.startTime || 'N/A',
                shiftEndTime: user.shiftGroup?.endTime || 'N/A',
                durationHours: user.shiftGroup?.durationHours || 'N/A'
            }
        };

        res.json(response);
    } catch (error) {
        console.error('Error fetching attendance debug info:', error);
        res.status(500).json({ error: 'Failed to fetch attendance debug information' });
    }
});

module.exports = router;











