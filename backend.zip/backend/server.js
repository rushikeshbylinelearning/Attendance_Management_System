// backend/server.js
require('dotenv').config();

// Validate environment variables before starting
const { validateAndExit } = require('./utils/envValidator');
validateAndExit();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const mongoose = require('mongoose');
const connectDB = require('./db');
const path = require('path');
const session = require('express-session');
const { startScheduledJobs } = require('./services/cronService');

// Import security and optimization modules
const { corsOptions } = require('./config/security');
const { requestLogger, logError } = require('./utils/logger');
const { optimizeConnection, createIndexes } = require('./utils/database');
const { sanitizeInput } = require('./middleware/validation');
const ssoService = require('./services/ssoService');
const performanceMonitor = require('./services/performanceMonitor');
const cacheService = require('./services/cacheService');
const ssoTokenAuth = require('./middleware/ssoTokenAuth');

// Pre-load all Mongoose models
require('./models/User');
require('./models/Shift');
require('./models/AttendanceLog');
require('./models/AttendanceSession');
require('./models/BreakLog');
require('./models/LeaveRequest');
require('./models/Setting');
require('./models/ExtraBreakRequest');
require('./models/NewNotification'); // <-- THIS IS THE FIX
require('./models/Holiday');
require('./models/OfficeLocation');

// --- Route Imports ---
const authRoutes = require('./routes/auth');
const autoLoginRoutes = require('./routes/autoLogin');
const attendanceRoutes = require('./routes/attendance');
const breakRoutes = require('./routes/breaks');
const adminRoutes = require('./routes/admin');
const employeeRoutes = require('./routes/employees');
const shiftRoutes = require('./routes/shifts');
const leaveRoutes = require('./routes/leaves');
const settingsRoutes = require('./routes/settingsRoutes');
const reportsRoutes = require('./routes/reports');
const userRoutes = require('./routes/users');
const newNotificationRoutes = require('./routes/newNotifications');
const officeLocationRoutes = require('./routes/officeLocations');
const manageRoutes = require('./routes/manage');
const analyticsRoutes = require('./routes/analytics');
const accountManagementRoutes = require('./routes/accountManagement');
const payrollRoutes = require('./routes/payrollRoutes');
const probationRoutes = require('./routes/probationRoutes');

// --- Models ---
const User = require('./models/User');

// SSO Configuration
const SSO_CONFIG = {
  secret: process.env.SSO_SECRET || 'sso-secret-key-change-in-production',
  issuer: process.env.SSO_ISSUER || 'sso-portal',
  audience: process.env.SSO_AUDIENCE || 'sso-apps',
  sessionSecret: process.env.SESSION_SECRET || 'your-session-secret',
  sessionMaxAge: 24 * 60 * 60 * 1000, // 24 hours
  // New RS256/JWKS support
  jwksUrl: process.env.SSO_JWKS_URL,
  publicKey: process.env.SSO_PUBLIC_KEY,
  validateUrl: process.env.SSO_VALIDATE_URL,
};

const app = express();

app.set('trust proxy', 1);

// Enable WebSocket support by ensuring proper headers
app.use((req, res, next) => {
  // Ensure Connection and Upgrade headers are preserved for WebSocket handshakes
  if (req.headers.upgrade === 'websocket') {
    res.setHeader('Connection', 'Upgrade');
    res.setHeader('Upgrade', 'websocket');
  }
  next();
});

// MongoDB connection will be handled in startServer() function
// Routes are registered before DB connection, but routes check DB before querying

// --- Security Middleware ---
// Get default directives and explicitly remove frame-ancestors to avoid duplicate
const defaultDirectives = helmet.contentSecurityPolicy.getDefaultDirectives();
delete defaultDirectives['frame-ancestors'];

app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        ...defaultDirectives,
        // Allow embedding from SSO portal (5175) and other internal apps
        'frame-ancestors': process.env.NODE_ENV === 'development' 
          ? ["'self'", "http://localhost:5173", "http://localhost:5174", "http://localhost:5175", "http://127.0.0.1:5173", "http://127.0.0.1:5174", "http://127.0.0.1:5175"]
          : ["'self'", "https://sso.legatolxp.online", "https://sso.bylinelms.com", "https://sso.leagatolxp.online"],
      },
    },
    // Disable X-Frame-Options since we're using CSP frame-ancestors instead
    frameguard: false,
  })
);

// Enhanced compression for production
app.use(compression({
  filter: (req, res) => {
    if (req.headers['x-no-compression']) {
      return false;
    }
    return compression.filter(req, res);
  },
  level: 6, // Compression level (0-9)
  threshold: 1024, // Only compress responses larger than 1KB
}));

app.use(cors(corsOptions));

// --- ADD IFRAME EMBEDDING SUPPORT ---
// Allow embedding in iframes from SSO portal and internal apps
// This middleware ensures X-Frame-Options is removed and CSP frame-ancestors is set
app.use((req, res, next) => {
  // Force remove X-Frame-Options header (in case it was set by another middleware)
  res.removeHeader("X-Frame-Options");
  
  // Get existing CSP header
  const existingCSP = res.getHeader('Content-Security-Policy') || '';
  
  // If frame-ancestors is not in CSP, add it
  if (!existingCSP.includes('frame-ancestors')) {
    const allowedOrigins = process.env.NODE_ENV === 'development' 
      ? "http://localhost:5173 http://localhost:5174 http://localhost:5175 http://127.0.0.1:5173 http://127.0.0.1:5174 http://127.0.0.1:5175"
      : "https://sso.legatolxp.online https://sso.bylinelms.com https://sso.leagatolxp.online";
    
    // If there's already a CSP, append to it, otherwise create new
    if (existingCSP) {
      res.setHeader("Content-Security-Policy", `${existingCSP}; frame-ancestors ${allowedOrigins};`);
    } else {
      res.setHeader("Content-Security-Policy", `frame-ancestors ${allowedOrigins};`);
    }
  }
  
  next();
});

// CORS debugging middleware (development only)
if (process.env.NODE_ENV === 'development') {
  app.use((req, res, next) => {
    if (req.method === 'OPTIONS' || req.headers.origin) {
      console.log(`🌐 CORS Request: ${req.method} ${req.url} from origin: ${req.headers.origin}`);
    }
    next();
  });
}

// --- Session Middleware ---
app.use(session({
  secret: SSO_CONFIG.sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // false for localhost development
    httpOnly: true,
    sameSite: 'lax', // Use 'lax' for localhost development
    path: '/', // Ensure cookie is available for all paths
    maxAge: SSO_CONFIG.sessionMaxAge,
    // Additional settings for cross-origin compatibility
    domain: undefined // Let browser handle domain
  },
  // Additional session store options for cross-origin compatibility
  name: 'connect.sid' // Standard session cookie name
}));

// --- Request Processing Middleware ---
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(sanitizeInput); // Sanitize all inputs
app.use(requestLogger); // Log all requests
app.use(performanceMonitor.trackRequest.bind(performanceMonitor)); // Track performance

// --- Rate Limiting Removed ---

// Optimized static file serving with caching
const staticOptions = {
    setHeaders: (res, filepath, stat) => {
        res.set('ngrok-skip-browser-warning', 'true');
        
        // Set cache headers based on file type
        const ext = path.extname(filepath).toLowerCase();
        
        // Images and fonts - cache for 1 year
        if (['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.ico', '.woff', '.woff2', '.ttf', '.eot'].includes(ext)) {
            res.set('Cache-Control', 'public, max-age=31536000, immutable');
        }
        // CSS and JS - cache for 1 day (in case of updates)
        else if (['.css', '.js'].includes(ext)) {
            res.set('Cache-Control', 'public, max-age=86400');
        }
        // HTML - no cache (always fresh)
        else if (['.html'].includes(ext)) {
            res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
        }
        // Everything else - cache for 1 hour
        else {
            res.set('Cache-Control', 'public, max-age=3600');
        }
        
        // Security headers
        res.set('X-Content-Type-Options', 'nosniff');
    },
    maxAge: process.env.NODE_ENV === 'production' ? '1y' : 0,
    etag: true,
    lastModified: true,
};

app.use('/avatars', express.static(path.join(__dirname, 'uploads/avatars'), staticOptions));
app.use('/public', express.static(path.join(__dirname, 'public'), staticOptions));

// --- SSO Authentication Middleware ---
app.use(ssoTokenAuth(SSO_CONFIG));

// --- API ROUTE MOUNTING ---
app.use('/api/auth', authRoutes);

// Add SSO auth routes
const ssoValidationRoutes = require('./routes/ssoValidation');
app.use('/api/auth', ssoValidationRoutes);

// Add SSO routes
const ssoRoutes = require('./routes/ssoRoutes');
app.use('/api/sso', ssoRoutes);

// Add auto-login routes
app.use('/api/auto-login', autoLoginRoutes);
app.use('/api/attendance', attendanceRoutes);
app.use('/api/breaks', breakRoutes);
app.use('/api/leaves', leaveRoutes);
app.use('/api/users', userRoutes);
app.use('/api/new-notifications', newNotificationRoutes); // Use new route
app.use('/api/admin/employees', employeeRoutes);
app.use('/api/admin/shifts', shiftRoutes);
app.use('/api/admin/settings', settingsRoutes);
app.use('/api/admin/reports', reportsRoutes);
app.use('/api/admin/office-locations', officeLocationRoutes);
app.use('/api/admin/manage', manageRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/admin', accountManagementRoutes);
app.use('/api/payroll', payrollRoutes);
app.use('/api/probation', probationRoutes);

// Debug route registration
console.log('Routes registered:');
console.log('- /api/admin/manage (manageRoutes)');
console.log('- /api/admin (adminRoutes)');
console.log('✅ AMS SSO Auto-Login route initialized at /api/auto-login/launch/:appId');

// Health check endpoint
app.get('/health', async (req, res) => {
  const healthStatus = performanceMonitor.getHealthStatus();
  const ssoJwksUrl = process.env.SSO_JWKS_URL;
  const ssoPublicKeyUrl = process.env.SSO_PUBLIC_KEY_URL;
  const ssoConfigured = !!(ssoJwksUrl || ssoPublicKeyUrl);
  
  // Check JWKS endpoint availability
  let jwksStatus = 'unknown';
  if (ssoJwksUrl) {
    try {
      const axios = require('axios');
      const response = await axios.get(ssoJwksUrl, { timeout: 5000 });
      jwksStatus = response.status === 200 ? 'OK' : 'ERROR';
    } catch (error) {
      jwksStatus = 'ERROR';
    }
  }
  
  res.json({
    ...healthStatus,
    ssoStatus: {
      configured: ssoConfigured,
      jwksUrl: ssoJwksUrl || null,
      jwksStatus: jwksStatus,
      publicKeyUrl: ssoPublicKeyUrl || null,
      algorithm: 'RS256',
      verificationMethod: ssoJwksUrl ? 'JWKS' : (ssoPublicKeyUrl ? 'Public Key' : 'None')
    },
    timestamp: new Date().toISOString(),
  });
});

// Performance metrics endpoint
app.get('/metrics', (req, res) => {
  const metrics = performanceMonitor.getMetrics();
  res.json(metrics);
});

// Cache statistics endpoint
app.get('/cache-stats', (req, res) => {
  const stats = cacheService.getStats();
  res.json(stats);
});

// SSO Logout endpoint
app.post('/sso/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('❌ Logout error:', err);
      return res.status(500).json({ success: false, message: 'Logout failed' });
    }
    const redirectUrl = process.env.NODE_ENV === 'production'
      ? 'https://sso.bylinelms.com/login'
      : 'http://localhost:3000/login';
    res.json({ success: true, message: 'Logged out', redirectUrl });
  });
});

// Development endpoint removed (rate limiting disabled)

// Catch-all for debugging unmatched routes (removed to prevent path-to-regexp errors)

// Root route removed to prevent conflict with SPA fallback

// Global error handling middleware
app.use((err, req, res, next) => {
  // Track error in performance monitor
  performanceMonitor.trackError(err, {
    url: req.url,
    method: req.method,
    body: req.body,
    params: req.params,
    query: req.query
  });

  logError(err, {
    url: req.url,
    method: req.method,
    body: req.body,
    params: req.params,
    query: req.query
  });

  // Don't leak error details in production
  const isDevelopment = process.env.NODE_ENV === 'development';
  
  res.status(err.status || 500).json({
    error: isDevelopment ? err.message : 'Internal Server Error',
    ...(isDevelopment && { stack: err.stack })
  });
});

// Serve static files from the React app build directory (after API routes)
// Use optimized settings for production
const frontendStaticOptions = {
    setHeaders: (res, filepath, stat) => {
        res.set('ngrok-skip-browser-warning', 'true');
        
        const ext = path.extname(filepath).toLowerCase();
        
        // Assets with hashes in filename - cache aggressively
        if (filepath.includes('-') && ['.js', '.css', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.woff', '.woff2'].includes(ext)) {
            res.set('Cache-Control', 'public, max-age=31536000, immutable');
        }
        // Images and fonts - cache for 1 year
        else if (['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.ico', '.woff', '.woff2', '.ttf', '.eot'].includes(ext)) {
            res.set('Cache-Control', 'public, max-age=31536000');
        }
        // CSS and JS - cache for 1 day
        else if (['.css', '.js'].includes(ext)) {
            res.set('Cache-Control', 'public, max-age=86400');
        }
        // HTML - no cache
        else if (['.html'].includes(ext)) {
            res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
            res.set('Pragma', 'no-cache');
            res.set('Expires', '0');
        }
        // Everything else - cache for 1 hour
        else {
            res.set('Cache-Control', 'public, max-age=3600');
        }
        
        // Security headers
        res.set('X-Content-Type-Options', 'nosniff');
    },
    maxAge: process.env.NODE_ENV === 'production' ? '1y' : 0,
    etag: true,
    lastModified: true,
    index: false, // Don't serve index.html automatically
};

app.use(express.static(path.join(__dirname, '../frontend/dist'), frontendStaticOptions));

// SPA fallback middleware: send back React's index.html file for client-side routing
app.use((req, res, next) => {
  // Skip if it's an API route or static file
  if (req.path.startsWith('/api') || req.path.startsWith('/avatars') || req.path.startsWith('/public')) {
    return next();
  }
  
  // CRITICAL: Remove X-Frame-Options and set frame-ancestors for HTML responses
  res.removeHeader("X-Frame-Options");
  const allowedOrigins = process.env.NODE_ENV === 'development' 
    ? "http://localhost:5173 http://localhost:5174 http://localhost:5175 http://127.0.0.1:5173 http://127.0.0.1:5174 http://127.0.0.1:5175"
    : "https://sso.legatolxp.online https://sso.bylinelms.com https://sso.leagatolxp.online";
  
  const existingCSP = res.getHeader('Content-Security-Policy') || '';
  if (existingCSP && !existingCSP.includes('frame-ancestors')) {
    res.setHeader("Content-Security-Policy", `${existingCSP}; frame-ancestors ${allowedOrigins};`);
  } else if (!existingCSP) {
    res.setHeader("Content-Security-Policy", `frame-ancestors ${allowedOrigins};`);
  }
  
  // For all other routes, serve the React app with no-cache headers
  res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  res.sendFile(path.join(__dirname, '../frontend/dist/index.html'));
});

const PORT = process.env.PORT || 3001;
const httpServer = require('http').createServer(app);

// --- MODIFIED: Initialize Socket.IO and the Manager ---
const { init } = require('./socket');
init(httpServer); // This now internally sets the io instance in socketManager

// Start server only after MongoDB connection is ready
const startServer = async () => {
  try {
    console.log('🔗 Starting server initialization...');
    
    // Connect to MongoDB FIRST before starting server
    await connectDB();
    console.log('✅ MongoDB connection ready');
    
    // Validate JWT configuration for RS256 enforcement
    const jwtUtils = require('./utils/jwtUtils');
    jwtUtils.validateRS256Configuration();
    
    // Create database indexes for optimization
    try {
      await createIndexes();
      console.log('✅ Database indexes created successfully');
    } catch (error) {
      console.error('Failed to create database indexes:', error);
    }
    
    // Start scheduled jobs after database is ready
    startScheduledJobs();
    console.log('✅ Scheduled jobs started');
    
    // Initialize SSO service (only if SSO_PUBLIC_KEY_URL is configured)
    // Note: SSO_SECRET is not used for RS256/JWKS verification, only for legacy HS256
    const ssoPublicKeyUrl = process.env.SSO_PUBLIC_KEY_URL;
    const ssoJwksUrl = process.env.SSO_JWKS_URL;
    
    if (ssoPublicKeyUrl) {
      await ssoService.initialize();
      console.log('[SSO] Legacy SSO service initialized (using public key URL)');
    } else if (ssoJwksUrl) {
      console.log('[SSO] Modern SSO service enabled (using JWKS for RS256 verification)');
      console.log(`[SSO] JWKS URL: ${ssoJwksUrl}`);
    } else {
      console.log('[SSO] SSO service disabled - no SSO_PUBLIC_KEY_URL or SSO_JWKS_URL configured');
      console.log('[SSO] To enable SSO, set SSO_JWKS_URL=http://localhost:3003/.well-known/jwks.json in .env');
    }
    
    // Start HTTP server only after all initialization is complete
    httpServer.listen(PORT, () => {
      console.log(`🚀 Server is running on port ${PORT}`);
      console.log(`📊 Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log('✅ Server initialization complete');
    });
    
  } catch (err) {
    console.error('❌ Failed to start server due to DB error:', err.message);
    console.error('❌ Server will exit. Please fix MongoDB connection and restart.');
    process.exit(1);
  }
};

// Start the server
startServer();