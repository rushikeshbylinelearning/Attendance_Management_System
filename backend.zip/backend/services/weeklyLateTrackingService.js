// backend/services/weeklyLateTrackingService.js

const WeeklyLateTracking = require('../models/WeeklyLateTracking');
const User = require('../models/User');

/**
 * Get the start and end dates of the current week (Monday to Sunday)
 */
const getCurrentWeekDates = () => {
  const now = new Date();
  const dayOfWeek = now.getDay();
  const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek; // Handle Sunday as start of week
  
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() + mondayOffset);
  weekStart.setHours(0, 0, 0, 0);
  
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6);
  weekEnd.setHours(23, 59, 59, 999);
  
  return {
    startDate: weekStart.toISOString().slice(0, 10),
    endDate: weekEnd.toISOString().slice(0, 10)
  };
};

/**
 * Track a late login for a user
 */
const trackLateLogin = async (userId, attendanceDate) => {
  try {
    const weekDates = getCurrentWeekDates();
    
    // Find or create weekly tracking record
    let trackingRecord = await WeeklyLateTracking.findOne({
      user: userId,
      weekStartDate: weekDates.startDate
    });
    
    if (!trackingRecord) {
      trackingRecord = new WeeklyLateTracking({
        user: userId,
        weekStartDate: weekDates.startDate,
        weekEndDate: weekDates.endDate,
        lateCount: 0,
        lateDates: []
      });
    }
    
    // Check if this date is already tracked
    if (!trackingRecord.lateDates.includes(attendanceDate)) {
      trackingRecord.lateCount += 1;
      trackingRecord.lateDates.push(attendanceDate);
      
        // Previously the system locked user accounts on the 4th late login.
        // Policy change (2025): Do NOT lock user accounts automatically for repeated late logins.
        // Instead, we only track the lateCount and let higher-level processes (email/hr) handle notifications.
        // No automatic call to lockUserAccount here.
      
      await trackingRecord.save();
    }
    
    return trackingRecord;
  } catch (error) {
    console.error('Error tracking late login:', error);
    throw error;
  }
};

/**
 * Lock user account after 4th late login
 */
const lockUserAccount = async (userId, trackingRecordId) => {
  // Locking via automated weekly late tracking has been disabled by policy.
  // Keep a placeholder implementation so any existing callers won't accidentally lock accounts.
  try {
    // Mark tracking record to indicate threshold was reached (no user account changes)
    await WeeklyLateTracking.findByIdAndUpdate(trackingRecordId, {
      isAccountLocked: false,
      // keep a note for audits
      lastLockAttemptedAt: new Date()
    });

    console.log(`LockUserAccount called for user ${userId} but automatic locking is disabled by policy.`);
  } catch (error) {
    console.error('Error in lockUserAccount placeholder:', error);
    throw error;
  }
};

/**
 * Unlock user account (admin/HR action)
 */
const unlockUserAccount = async (userId, unlockedBy, reason) => {
  try {
    // Update user account status
    await User.findByIdAndUpdate(userId, {
      isActive: true,
      accountLocked: false,
      lockedReason: null,
      lockedAt: null,
      unlockedAt: new Date(),
      unlockedBy: unlockedBy
    });
    
    // Update current week's tracking record
    const weekDates = getCurrentWeekDates();
    await WeeklyLateTracking.findOneAndUpdate(
      { user: userId, weekStartDate: weekDates.startDate },
      {
        isAccountLocked: false,
        unlockedAt: new Date(),
        unlockedBy: unlockedBy,
        unlockReason: reason
      }
    );
    
    console.log(`Account unlocked for user ${userId} by ${unlockedBy}`);
  } catch (error) {
    console.error('Error unlocking user account:', error);
    throw error;
  }
};

/**
 * Check if user account is locked
 */
const isAccountLocked = async (userId) => {
  try {
    const user = await User.findById(userId).select('isActive accountLocked lockedReason lockedAt');
    return {
      isLocked: !user.isActive || user.accountLocked,
      reason: user.lockedReason,
      lockedAt: user.lockedAt
    };
  } catch (error) {
    console.error('Error checking account lock status:', error);
    return { isLocked: false };
  }
};

/**
 * Get weekly late statistics for a user
 */
const getWeeklyLateStats = async (userId) => {
  try {
    const weekDates = getCurrentWeekDates();
    const trackingRecord = await WeeklyLateTracking.findOne({
      user: userId,
      weekStartDate: weekDates.startDate
    });
    
    return {
      currentWeekLateCount: trackingRecord?.lateCount || 0,
      lateDates: trackingRecord?.lateDates || [],
      isAccountLocked: trackingRecord?.isAccountLocked || false,
      remainingLateLogins: Math.max(0, 3 - (trackingRecord?.lateCount || 0))
    };
  } catch (error) {
    console.error('Error getting weekly late stats:', error);
    return {
      currentWeekLateCount: 0,
      lateDates: [],
      isAccountLocked: false,
      remainingLateLogins: 3
    };
  }
};

module.exports = {
  trackLateLogin,
  lockUserAccount,
  unlockUserAccount,
  isAccountLocked,
  getWeeklyLateStats,
  getCurrentWeekDates
};

